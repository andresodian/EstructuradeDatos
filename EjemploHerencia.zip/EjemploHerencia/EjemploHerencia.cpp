// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Triangulo.h"
#include "Rectangulo.h"

using namespace std;

int main(void) {
	Rectangulo Rect;
	int base, altura;

	Rect.setWidth(5);
	Rect.setHeight(7);

	// Muestra el �rea de un rectangulo
	cout << "Total area: " << Rect.getArea() << endl;
	Triangulo Tri;
	cout << "Ingrese el dato de la base: ";
	cin >> base;
	cout << "Ingrese el dato de la altura: ";
	cin >> altura;
	Tri.setWidth(base);
	Tri.setHeight(altura);
	cout << "Total del area del triangulo es: " << Tri.getArea() << endl;
	
	Triangulo *emanuel = new Triangulo();
	cout << "Ingrese el dato de la base: ";
	cin >> base;
	cout << "Ingrese el dato de la altura: ";
	cin >> altura;
	emanuel->setWidth(base);
	emanuel->setHeight(altura);
	cout << "Total del area del triangulo es: " << emanuel->getArea();
   
	return 0;
}