#include "stdafx.h"
#include "Triangulo.h"
Triangulo::Triangulo() {

}
