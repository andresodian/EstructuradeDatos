#pragma once
#include "Shape.h"
class Triangulo : public Shape {
public:
	Triangulo();
	int getArea() {
		return (width * height) / 2;
	}
	
};

